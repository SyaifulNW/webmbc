
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <h3 class="mb-4">Detail Database Calon Peserta</h3>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Detail Data Calon Peserta: <?php echo e($data->nama); ?>

        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <td><?php echo e($data->id); ?></td>
                </tr>
                <tr>
                    <th>Nama</th>
                    <td><?php echo e($data->nama); ?></td>
                </tr>
                <tr>
                    <th>Leads</th>
                    <td><?php echo e($data->leads); ?></td>
                </tr>
                <tr>
                    <th>Kota</th>
                    <td><?php echo e($data->kota_nama); ?></td>
                </tr>
                <tr>
                    <th>Provinsi</th>
                    <td><?php echo e($data->provinsi_nama); ?></td>
                </tr>
                <tr>
                    <th>Nama Bisnis</th>
                    <td><?php echo e($data->nama_bisnis); ?></td>
                </tr>
                <tr>
                    <th>Jenis Bisnis</th>
                    <td><?php echo e($data->jenisbisnis); ?></td>
                </tr>
                <tr>
                    <th>No. Whatsapp</th>
                    <td><?php echo e($data->no_wa); ?></td>
                </tr>
                <tr>
                    <th>Kendala</th>
                    <td><?php echo e($data->kendala); ?></td>
                </tr>
                <tr>
                    <th>Situasi Bisnis</th>
                    <td><?php echo e($data->situasi_bisnis); ?></td>
                </tr>
                <tr>
                    <th>Ikut Kelas</th>
                    <td><?php echo e($data->ikut_kelas == 1 ? 'Ya' : 'Tidak'); ?></td>
                </tr>
                <tr>
                    <th>Kelas</th>
                    <td>
                        <?php if($data->kelas_id): ?>
                            <?php echo e($data->kelas->nama_kelas); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <!-- Add more fields as necessary -->
            </table>
        </div>
    </div>
    <div class="mt-3">
        <a href="<?php echo e(route('admin.database.database')); ?>" class="btn btn-secondary">Kembali ke Daftar</a>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmbc\resources\views\admin\database\show.blade.php ENDPATH**/ ?>