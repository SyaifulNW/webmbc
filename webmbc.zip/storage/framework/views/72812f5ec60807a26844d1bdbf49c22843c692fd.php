<tr>
    <td><?php echo e($loop->iteration); ?></td>
    <td><?php echo e($item->nama); ?></td>
    <td><?php echo e($item->status_peserta); ?></td>
    <td><?php echo e($item->leads); ?></td>
    <td><?php echo e($item->provinsi_nama); ?></td>
    <td><?php echo e($item->kota_nama); ?></td>
    <td><?php echo e($item->nama_bisnis); ?></td>
    <td><?php echo e($item->jenisbisnis); ?></td>
    <td><?php echo e($item->no_wa); ?></td>
    <td><?php echo e($item->situasi_bisnis); ?></td>
    <td><?php echo e($item->kendala); ?></td>

    <td>
        <?php if($item->kelas_id): ?>
            <?php echo e($item->kelas->nama_kelas); ?>

        <?php else: ?>
            -
        <?php endif; ?>
    </td>

    <?php if(auth()->user()->email == 'mbchamasah@gmail.com'): ?>
        <td><?php echo e($item->created_by); ?></td>
        <td><?php echo e($item->created_by_role); ?></td>
    <?php endif; ?>

    
    <td>
        
    </td>
</tr><?php /**PATH C:\xampp\htdocs\webmbc\resources\views\admin\database\row.blade.php ENDPATH**/ ?>