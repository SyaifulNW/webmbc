
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <h3 class="mb-4">Detail Sales Plan</h3>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Detail Sales Plan: <?php echo e($data->kelas->nama_kelas); ?> &nbsp; &nbsp; &nbsp;  <?php echo e($data->nama); ?>

        </div>
        </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <td><?php echo e($salesplan->id); ?></td>
                </tr>
                <tr>
                    <th>Nama</th>
                    <td><?php echo e($salesplan->data->nama); ?></td>
                </tr>
                <tr>
                    <th>Leads</th>
                    <td><?php echo e($salesplan->data->leads); ?></td>
                </tr>
                <tr>
                    <th>Situasi</th>
                    <td><?php echo e($salesplan->data->situasibisnis); ?></td>
                </tr>
           
                <!-- Add more fields as necessary -->
            </table>
        </div>
    </div>
    <div class="mt-3">
        <a href="<?php echo e(route('admin.database.database')); ?>" class="btn btn-secondary">Kembali ke Daftar</a>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmbc\resources\views\admin\salesplan\show.blade.php ENDPATH**/ ?>