
<?php $__env->startSection('content'); ?>
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        font-size: 14px;
        padding: 6px;
        text-align: left;
    }

    @media  only screen and (max-width: 768px) {

        table,
        thead,
        tbody,
        th,
        td,
        tr {
            display: block;
        }

        thead {
            display: none;
        }

        td {
            position: relative;
            padding-left: 50%;
        }

        td:before {
            position: absolute;
            left: 6px;
            white-space: nowrap;
            font-weight: bold;
        }

        td:nth-of-type(1):before {
            content: "Nama";
        }

        td:nth-of-type(2):before {
            content: "Kelas";
        }

        td:nth-of-type(3):before {
            content: "FU1 Hasil";
        }

        td:nth-of-type(4):before {
            content: "FU1 TL";
        }

        td:nth-of-type(5):before {
            content: "FU2 Hasil";
        }

        td:nth-of-type(6):before {
            content: "FU2 TL";
        }

        td:nth-of-type(7):before {
            content: "FU3 Hasil";
        }

        td:nth-of-type(8):before {
            content: "FU3 TL";
        }

        td:nth-of-type(9):before {
            content: "FU4 Hasil";
        }

        td:nth-of-type(10):before {
            content: "FU4 TL";
        }

        td:nth-of-type(11):before {
            content: "FU5 Hasil";
        }

        td:nth-of-type(12):before {
            content: "FU5 TL";
        }
    }
</style>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">
        Sales Plan
        <?php if($kelasFilter): ?>
        / <?php echo e($kelasFilter); ?>

        <?php endif; ?>
    </h1>

    <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item">Sales Plan</li>
            <?php if($kelasFilter): ?>
            <li class="breadcrumb-item active"><?php echo e($kelasFilter); ?></li>
            <?php endif; ?>
        </ol>
    </div>
</div>

<?php if(session('message')): ?>
<div class="alert alert-info">
    <?php echo e(session('message')); ?>

</div>
<?php endif; ?>

<?php if($salesplans->isEmpty()): ?>
<div class="alert alert-info">
    Tidak ada data yang sesuai dengan filter.
</div>
<?php else: ?>

<?php endif; ?>

<div class="container">

    <a href="<?php echo e(route('salesplan.export')); ?>" class="btn btn-success mb-3">
        Download Excel
    </a>
    <div class="card shadow-lg border-0 rounded-lg mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-chart-line"></i> Daftar Sales Plan</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="text-white" style="background-color:#25799E;">


                        <tr>
                            <th rowspan="3">No</th>
                            <th rowspan="3">Nama</th>
                            <th rowspan="3">Situasi Bisnis</th>
                            <th rowspan="3">Kendala</th>

                            
                            <th colspan="10" class="text-center">Follow Up</th>

                            <th rowspan="3">Potensi</th>
                            <th rowspan="3">Keterangan</th>
                            <th rowspan="5">Status</th>
                                 <?php if(Auth::user()->email == "mbchamasah@gmail.com"): ?> 
                            <th rowspan="3">Input Oleh</th>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <th colspan="2" class="text-center">FU <?php echo e($i); ?></th>
                                <?php endfor; ?>
                        </tr>
                        <tr>
                            
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <th>Hasil</th>
                                <th>Tindak Lanjut</th>
                                <?php endfor; ?>
                        </tr>
                    </thead>



                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $salesplans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                        $rowColors = [
                        'ok' => 'table-info',
                        'hot' => 'table-success', // hijau
                        'warm' => 'table-warning', // kuning
                        'No' => 'table-danger', // merah
                        'Cold' => 'table-white' // abu
                        ];

                        $statusTexts = [
                        'ok'=> 'Sudah Transfer',
                        'hot' => 'Mau Transfer',
                        'warm' => 'Tertarik',
                        'No' => 'Tidak Transfer',
                        'Cold' => 'Belum Transfer',
                        ];

                        $rowClass = $rowColors[$plan->status] ?? '';
                        $badgeText = $statusTexts[$plan->status] ?? ucfirst($plan->status);
                        ?>

                        <tr class="<?php echo e($rowClass); ?>

                            <?php if($plan->status == 'sudah_transfer'): ?> table-info
    <?php elseif($plan->status == 'mau_transfer'): ?> table-success
    <?php elseif($plan->status == 'tertarik'): ?> table-warning
    <?php elseif($plan->status == 'no'): ?> table-danger
    <?php elseif($plan->status == 'cold'): ?> table-secondary
    <?php endif; ?>">
                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($plan->nama ?? '-'); ?></td>
                            <td><?php echo e($plan->situasi_bisnis ?? '-'); ?></td>
                            <td><?php echo e($plan->kendala ?? '-'); ?></td>


                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <td contenteditable="true" class="editable bg-light"
                                data-id="<?php echo e($plan->id); ?>"
                                data-field="fu<?php echo e($i); ?>_hasil">
                                <?php echo e($plan->{'fu'.$i.'_hasil'} ?? '-'); ?>

                                </td>

                                <td contenteditable="true" class="editable text-dark"
                                    data-id="<?php echo e($plan->id); ?>"
                                    data-field="fu<?php echo e($i); ?>_tindak_lanjut">
                                    <?php echo e($plan->{'fu'.$i.'_tindak_lanjut'} ?? '-'); ?>

                                </td>
                                <?php endfor; ?>

                                <td contenteditable="true" class="editable fw-bold text-dark text-bold"
                                    data-id="<?php echo e($plan->id); ?>"
                                    data-field="nominal">
                                    <?php echo e(number_format($plan->nominal, 0, ',', '.')); ?>

                                </td>

                                <td contenteditable="true" class="editable"
                                    data-id="<?php echo e($plan->id); ?>"
                                    data-field="keterangan">
                                    <?php echo e($plan->keterangan); ?>

                                </td>
                                <td class="text-center">
                                    <select class="form-control form-control-sm status-dropdown 
                                      status-<?php echo e($plan->status); ?>"
                                        data-id="<?php echo e($plan->id); ?>"
                                        style="min-width: 160px;">
                                        <option value="sudah_transfer" <?php echo e($plan->status == 'sudah_transfer' ? 'selected' : ''); ?>>Sudah Transfer</option>
                                        <option value="mau_transfer" <?php echo e($plan->status == 'mau_transfer' ? 'selected' : ''); ?>>Mau Transfer</option>
                                        <option value="tertarik" <?php echo e($plan->status == 'tertarik' ? 'selected' : ''); ?>>Tertarik</option>
                                        <option value="cold" <?php echo e($plan->status == 'cold' ? 'selected' : ''); ?>>Cold</option>
                                        <option value="no" <?php echo e($plan->status == 'no' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                </td>


                                <style>
                                    /* Style default */
                                    .status-dropdown {
                                        min-width: 160px;
                                        padding: 4px 8px;
                                        font-size: 14px;
                                        font-weight: bold;
                                        color: #fff;
                                        /* teks default putih */
                                    }

                                    /* Warna sesuai status */
                                    .status-sudah_transfer {
                                        background-color: #48e7ecff;
                                        color: #030303ff;
                                    }

                                    /* Hijau */
                                    .status-mau_transfer {
                                        background-color: #1cff07ff;
                                        color: #000;
                                    }

                                    /* Kuning */
                                    .status-tertarik {
                                        background-color: #ffd900ff;
                                        color: #000;
                                    }

                                    /* Biru */
                                    .status-cold {
                                        background-color: #6c757d;
                                    }

                                    /* Abu gelap */
                                    .status-no {
                                        background-color: #d12020ff;
                                        color: #faf3f3ff;
                                    }

                                    /* Abu terang */
                                </style>
                                <script>
                                    $(document).on('change', '.status-dropdown', function() {
                                        let id = $(this).data('id');
                                        let value = $(this).val();
                                        let dropdown = $(this);

                                        $.ajax({
                                            url: '/admin/salesplan/' + id,
                                            method: 'PUT',
                                            data: {
                                                _token: '<?php echo e(csrf_token()); ?>',
                                                status: value
                                            },
                                            success: function(res) {
                                                console.log('Status updated:', res);

                                                // Hapus semua class lama
                                                dropdown.removeClass("status-sudah_transfer status-mau_transfer status-tertarik status-cold status-no");

                                                // Tambahkan class baru sesuai value
                                                dropdown.addClass("status-" + value);
                                            },
                                            error: function(xhr) {
                                                console.error(xhr.responseText);
                                                alert('Gagal update status');
                                            },
                                            success: function(res) {
                                                console.log('Status updated:', res);

                                                // Hapus semua class lama di dropdown
                                                dropdown.removeClass("status-sudah_transfer status-mau_transfer status-tertarik status-cold status-no");

                                                // Tambahkan class baru sesuai value
                                                dropdown.addClass("status-" + value);

                                                // Update warna <tr>
                                                let row = dropdown.closest('tr');
                                                row.removeClass("table-info table-success table-warning table-danger table-secondary");
                                                if (value === "sudah_transfer") row.addClass("table-info");
                                                if (value === "mau_transfer") row.addClass("table-success");
                                                if (value === "tertarik") row.addClass("table-warning");
                                                if (value === "no") row.addClass("table-danger");
                                                if (value === "cold") row.addClass("table-secondary");
                                            }


                                        });
                                    });
                                </script>





                                <!-- <td class="text-center">
                                    <a href="<?php echo e(route('admin.salesplan.edit', $plan->id)); ?>"
                                        class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a>
                                </td> -->
                              <?php if(Auth::user()->email == "mbchamasah@gmail.com"): ?> 
                                <td>
                                    <?php switch($plan->created_by):
                                    case (1): ?>
                                    Administrator
                                    <?php break; ?>
                                    <?php case (2): ?>
                                    Linda
                                    <?php break; ?>
                                    <?php case (3): ?>
                                    Yasmin
                                    <?php break; ?>
                                    <?php case (4): ?>
                                    Tursia
                                    <?php break; ?>
                                    <?php case (5): ?>
                                    Livia
                                    <?php break; ?>
                                    <?php case (6): ?>
                                    Shafa
                                    <?php break; ?>
                                    <?php default: ?>
                                    -
                                    <?php endswitch; ?>
                                </td>
                                <?php endif; ?>
                                </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="22" class="text-center text-muted">
                                Tidak ada data sales plan ditemukan.
                            </td>
                        </tr>

                        <?php endif; ?>
                    </tbody>
                </table>
                 
            </div>
        <div class="d-flex justify-content-center mt-3">
    <?php echo e($salesplans->links('pagination::bootstrap-4')); ?>

</div>


        </div>
    </div>

    <script>
        $(document).on('blur', '.editable', function() {
            let id = $(this).data('id');
            let field = $(this).data('field');
            let value = $(this).text().trim();

            $.ajax({
                url: "/admin/salesplan/inline-update", // relative URL, auto ikut domain aktif
                type: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: id,
                    field: field,
                    value: value
                },
                success: function(res) {
                    console.log("✅ Update sukses:", res);
                },
                error: function(xhr, status, error) {
                    console.error("❌ Gagal update:", xhr.responseText);
                    alert("Gagal update data!");
                }
            });
        });
    </script>



    <!-- Modal Edit Status Potensi Keterangan-->
    <!-- Modal Edit Status Potensi Keterangan -->
    <!-- Modal Edit Status Potensi Keterangan -->



</div>




<h4 style="margin-top: 30px; font-weight: bold;">Daftar Peserta / HRD Mastery</h4>
<div style="overflow-x: auto; white-space: nowrap;">
    <table style="border-collapse: collapse; width: 100%; text-align: center; font-family: Arial, sans-serif; font-size: 14px; min-width: 500px;">
        <thead>
            <tr style="background: linear-gradient(to right, #376bb9ff, #1c7f91ff); color: white;">
                <th style="padding: 10px; border: 1px solid #ccc;">No</th>
                <th style="padding: 10px; border: 1px solid #ccc;">Nama</th>
                <th style="padding: 10px; border: 1px solid #ccc;">Nominal</th>
            </tr>
        </thead>
        <tbody>

            <tr style="background: #fdfdfd; color: black;">
                <td style="padding: 8px; border: 1px solid #ccc;"></td>
                <td style="padding: 8px; border: 1px solid #ccc;"></td>
                <td style="padding: 8px; border: 1px solid #ccc;"></td>
            </tr>

            <tr>
                <td colspan="3" style="text-align: center; padding: 15px; color: #999;">
                    Belum ada peserta yang transfer.
                </td>
            </tr>

        </tbody>
    </table>
</div>


</div>
<script>
    $(document).ready(function() {
        $('.status-cell').each(function() {
            const status = $(this).text().trim().toLowerCase();
            const row = $(this).closest('tr');

            switch (status) {
                case 'hot':
                    row.css('background-color', '#d4edda'); // Hijau muda
                    break;
                case 'warm':
                    row.css('background-color', '#fff3cd'); // Kuning muda
                    break;
                case 'cold':
                    row.css('background-color', '#ffffff'); // Putih (default)
                    break;
                case 'no':
                    row.css('background-color', '#f8d7da'); // Merah muda
                    break;
                default:
                    row.css('background-color', '#f0f0f0'); // Abu (jika status tidak dikenal)
            }
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#example').DataTable({
            "lengthMenu": [
                [15, 25, 50, 100, 500],
                [15, 25, 50, 100, 500]
            ]
        });
    });
</script>

<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<?php echo $__env->make('layouts.masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmbc\resources\views\admin\salesplan\index.blade.php ENDPATH**/ ?>