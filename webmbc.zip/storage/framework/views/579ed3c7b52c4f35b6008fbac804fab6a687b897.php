

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Edit Sales Plan</h3>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.salesplan.update', $plan->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <!-- <div class="form-group">
                    <label for="nominal">Potensi</label>
                    <input
                        type="number"
                        name="nominal"
                        class="form-control"
                        id="nominal"
                        value="<?php echo e(old('nominal', $plan->nominal)); ?>"
                        placeholder="Masukkan nominal">
                </div> -->

                
                <!-- <div class="form-group">
                    <label>Keterangan</label>
                    <textarea
                        name="keterangan"
                        class="form-control"
                        rows="2"
                        placeholder="Masukkan keterangan"><?php echo e(old('keterangan', $plan->keterangan)); ?></textarea>
                </div> -->

                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="cold" <?php echo e($plan->status == 'cold' ? 'selected' : ''); ?>>Cold</option>
                        <option value="warm" <?php echo e($plan->status == 'warm' ? 'selected' : ''); ?>>Mau Transfer</option>
                        <option value="hot" <?php echo e($plan->status == 'hot' ? 'selected' : ''); ?>>Sudah Transfer</option>
                        <option value="no" <?php echo e($plan->status == 'no' ? 'selected' : ''); ?>>No</option>
                    </select>
                </div>

                <div class="mt-3">
                    <button type="submit" class="btn btn-success">Simpan</button>
                    <a href="<?php echo e(route('admin.salesplan.index')); ?>" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmbc\resources\views\admin\salesplan\edit.blade.php ENDPATH**/ ?>