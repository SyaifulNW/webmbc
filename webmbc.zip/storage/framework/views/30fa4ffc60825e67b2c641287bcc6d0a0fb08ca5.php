
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="h3 mb-4 text-gray-800">Detail Alumni</h1>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Detail Data Alumni: <?php echo e($alumni->nama); ?>

        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <td><?php echo e($alumni->id); ?></td>
                </tr>
                <tr>
                    <th>Nama</th>
                    <td><?php echo e($alumni->nama); ?></td>
                </tr>
                <tr>
                    <th>Sumber Leads</th>
                    <td><?php echo e($alumni->leads); ?></td>
                </tr>
                <tr>
                    <th>Provinsi</th>
                    <td><?php echo e($alumni->provinsi_nama); ?></td>
                </tr>
                <tr>
                    <th>Kota</th>
                    <td><?php echo e($alumni->kota_nama); ?></td>
                </tr>
                <tr>
                    <th>Nama Bisnis</th>
                    <td><?php echo e($alumni->nama_bisnis); ?></td>
                </tr>
                <tr>
                    <th>Jenis Bisnis</th>
                    <td><?php echo e($alumni->jenisbisnis); ?></td>
                </tr>
                <tr>
                    <th>No. Whatsapp</th>
                    <td><?php echo e($alumni->no_wa); ?></td>
                </tr>
                <tr>
                    <th>Kendala</th>
                    <td><?php echo e($alumni->kendala); ?></td>
                </tr>
                <tr>
                    <th>Sudah Pernah Ikut Kelas</th>
                    <td><?php echo e($alumni->sudah_pernah_ikut_kelas_apa_saja); ?></td>
                </tr>
                <tr>
                    <th>Kelas Yang Belum Diikuti</th>
                    <td><?php echo e($alumni->kelas_yang_belum_diikuti_apa_saja); ?></td>
                </tr>
            </table>

        </div>
    </div>
    <div class="mt-3">
        <a href="<?php echo e(route('admin.alumni.alumni')); ?>" class="btn btn-secondary">Kembali ke Daftar Alumni</a>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmbc\resources\views\admin\alumni\show.blade.php ENDPATH**/ ?>