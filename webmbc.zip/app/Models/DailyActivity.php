<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class DailyActivity extends Model
{
    use HasFactory;
      
      protected $fillable = ['tanggal'];

    public function items()
    {
        return $this->hasMany(DailyActivityitem::class);
    }
}
